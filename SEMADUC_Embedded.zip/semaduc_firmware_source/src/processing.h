/*
 * processing.h
 *
 *  Created on: 13.12.2019.
 *      Author: aleksandar.spasic
 */
#define STX1 0x02
#define ETX1 0x03
#define data_lenght 100
#define	data_buffer_lenght  1+data_lenght+1

#ifndef PROCESSING_H_
#define PROCESSING_H_
#include <stdbool.h>
#include <stdint.h>

bool processing_get_start();
void processing_set_start(bool x);
bool processing_get_stop();
void processing_set_stop(bool x);
bool processing_get_data_processing();
void processing_set_timeout_cnt(int x);
void processing_set_timeout_start(bool x);
bool processing_get_timeout_start();
uint16_t* processing_get_data_buffer_cnt();
uint8_t*  processing_get_data_buffer();
uint8_t* processing_get_buffer_test();
uint16_t* processing_get_buffer_test_cnt();
bool processing_get_data_ready();
void processing_set_data_ready(bool x);
bool processing_get_data_check();
void processing_set_data_check(bool x);

void processing_start_acquisition();
void processing_stop_acquisition();
void processing_data_acquisition();
void processing_timeout();


#endif /* PROCESSING_H_ */
