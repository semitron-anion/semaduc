/*
 * callback.h
 *
 *  Created on: 12.12.2019.
 *      Author: aleksandar.spasic
 */

#ifndef CALLBACK_H_
#define CALLBACK_H_
void* callback_get_uart0();
void* callback_get_uart1();
void* callback_get_gpio();

#endif /* CALLBACK_H_ */
