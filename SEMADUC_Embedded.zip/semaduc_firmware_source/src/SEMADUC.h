/*****************************************************************************
 * SEMADUC.h
 *****************************************************************************/

#ifndef __SEMADUC_H__
#define __SEMADUC_H__

/* Add your custom header content here */
#include "processing.h"
#include "peripheral.h"
#include "ADAC2.h"

#endif /* __SEMADUC_H__ */
