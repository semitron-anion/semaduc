/*
 * peripheral.c
 *
 *  Created on: 12.12.2019.
 *      Author: aleksandar.spasic
 */
#include "peripheral.h"
#include "callback.h"

PinMap LED1 = {ADI_GPIO_PORT2, ADI_GPIO_PIN_2};
PinMap LED2 = {ADI_GPIO_PORT2, ADI_GPIO_PIN_10};
PinMap BTN1 = {ADI_GPIO_PORT1, ADI_GPIO_PIN_0};
PinMap BTN2 = {ADI_GPIO_PORT0, ADI_GPIO_PIN_9};

PinMap ADAC_CS  = {ADI_GPIO_PORT2, ADI_GPIO_PIN_8};
PinMap ADAC_RST = {ADI_GPIO_PORT0, ADI_GPIO_PIN_14};
PinMap ADAC_ALT = {ADI_GPIO_PORT1, ADI_GPIO_PIN_13};
PinMap ADAC_RDY = {ADI_GPIO_PORT2, ADI_GPIO_PIN_1};

PinMap RS485_RE = {ADI_GPIO_PORT0, ADI_GPIO_PIN_8}; //41
PinMap RS485_DE = {ADI_GPIO_PORT1, ADI_GPIO_PIN_5}; //21

uint8_t spidevicemem[ADI_SPI_MEMORY_SIZE];
ADI_SPI_HANDLE hDevice;
ADI_SPI_TRANSCEIVER transceive;
uint8_t gpioMemory[ADI_GPIO_MEMORY_SIZE] = {0};
static ADI_UART_HANDLE hDevice_UART0;
static uint8_t UartDeviceMem0[ADI_UART_BIDIR_MEMORY_SIZE*2];
void *test;
static ADI_UART_HANDLE hDevice_UART1;
static uint8_t UartDeviceMem1[ADI_UART_BIDIR_MEMORY_SIZE];
static char RX_UART1 = 0;
static char RX_UART0 = 0;


void gpio_init();
void uart_init();
void spi_init();

void spi_send(uint8_t *transmit, uint16_t transmit_lenght, uint8_t *recive, uint16_t recive_lenght){
	bool complete = false;
    transceive.TransmitterBytes = transmit_lenght;
    transceive.ReceiverBytes = recive_lenght;
    transceive.pTransmitter = transmit;
    transceive.pReceiver = recive;
    adi_gpio_SetLow(ADAC_CS.Port, ADAC_CS.Pins);
	adi_spi_MasterSubmitBuffer(hDevice, &transceive);
	while(complete == false){
		adi_spi_isBufferAvailable(hDevice, &complete);
	}
	adi_gpio_SetHigh(ADAC_CS.Port, ADAC_CS.Pins);
}
void peripheral_init(){
	adi_pwr_Init();
	adi_pwr_SetClockDivider(ADI_CLOCK_HCLK, 1u);
	adi_pwr_SetClockDivider(ADI_CLOCK_PCLK, 1u);
	adi_pwr_UpdateCoreClock();

	gpio_init();
	uart_init();
	spi_init();
}

void gpio_init(){
	adi_gpio_Init(gpioMemory, ADI_GPIO_MEMORY_SIZE );
	adi_gpio_OutputEnable(LED1.Port, LED1.Pins, true);			//LED
	adi_gpio_OutputEnable(LED2.Port, LED2.Pins, true);			//LED
	adi_gpio_InputEnable(BTN1.Port, BTN1.Pins, true);			//BTN1
	adi_gpio_InputEnable(BTN2.Port, BTN2.Pins, true);			//BTN2
	adi_gpio_OutputEnable(RS485_RE.Port, RS485_RE.Pins, true);	//485 RE
	adi_gpio_OutputEnable(RS485_DE.Port, RS485_DE.Pins, true);	//485 DE

	adi_gpio_OutputEnable(ADAC_CS.Port, ADAC_CS.Pins, true);
	adi_gpio_SetHigh(ADAC_CS.Port, ADAC_CS.Pins);

	adi_gpio_OutputEnable(ADAC_RST.Port, ADAC_RST.Pins, true);
	adi_gpio_SetHigh(ADAC_RST.Port, ADAC_RST.Pins);

	adi_gpio_InputEnable(ADAC_ALT.Port, ADAC_ALT.Pins, true);
	adi_gpio_InputEnable(ADAC_RDY.Port, ADAC_RDY.Pins, true);

	adi_gpio_SetLow(LED1.Port, LED1.Pins);
	adi_gpio_SetLow(LED2.Port, LED2.Pins);

	adi_gpio_GroupInterruptPolarityEnable(ADAC_RDY.Port, ADAC_RDY.Pins, false);
	adi_gpio_RegisterCallback(ADI_GPIO_INTA_IRQ, callback_get_gpio(), NULL);
}
void uart_init(){
	adi_uart_Open(0, ADI_UART_DIR_BIDIRECTION, UartDeviceMem0, ADI_UART_BIDIR_MEMORY_SIZE*2, &hDevice_UART0);

	adi_uart_ConfigBaudRate(hDevice_UART0, 3, 2, 719, 3);//115200 @26Mhz PCLK

	adi_uart_EnableFifo(hDevice_UART0, true);
	adi_uart_SetRxFifoTriggerLevel(hDevice_UART0, ADI_UART_RX_FIFO_TRIG_LEVEL_4BYTE);
	adi_uart_RegisterCallback(hDevice_UART0, callback_get_uart0(), hDevice_UART0);
	adi_uart_SubmitRxBuffer(hDevice_UART0, &RX_UART0, 1, 1);
	adi_uart_SubmitRxBuffer(hDevice_UART0, &RX_UART0, 1, 1);

	adi_uart_Open(1, ADI_UART_DIR_BIDIRECTION, UartDeviceMem1, ADI_UART_BIDIR_MEMORY_SIZE, &hDevice_UART1);
	adi_uart_ConfigBaudRate(hDevice_UART1, 688, 3, 2000, 0);//2400 @26Mhz PCLK

	adi_uart_EnableFifo(hDevice_UART1, true);
	adi_uart_SetRxFifoTriggerLevel(hDevice_UART1, ADI_UART_RX_FIFO_TRIG_LEVEL_4BYTE);
	adi_uart_RegisterCallback(hDevice_UART1, callback_get_uart1(), hDevice_UART1);

	adi_uart_SubmitRxBuffer(hDevice_UART1, &RX_UART1, 1, 1);
}
void spi_init(){
	adi_spi_Open(0, spidevicemem, ADI_SPI_MEMORY_SIZE, &hDevice);
	adi_spi_SetBitrate(hDevice, 4000000);
	adi_spi_SetIrqmode(hDevice, 0u);
	adi_spi_SetClockPhase(hDevice, true);
	adi_spi_SetClockPolarity(hDevice, false);
	adi_spi_SetMasterMode(hDevice, true);

    transceive.TransmitterBytes = 4;
    transceive.ReceiverBytes = 4;

    transceive.nTxIncrement = 1;
    transceive.nRxIncrement = 1;
    transceive.bDMA = false;
    transceive.bRD_CTL = false;
}

/*set/get*/

inline ADI_UART_HANDLE peripherial_get_uart0(){
	return hDevice_UART0;
}
inline ADI_UART_HANDLE peripherial_get_uart1(){
	return hDevice_UART1;
}
inline char* peripherial_get_rxuart0(){
	return &RX_UART0;
}
inline char* peripherial_get_rxuart1(){
	return &RX_UART1;
}



