/*
 * processing.c
 *
 *  Created on: 13.12.2019.
 *      Author: aleksandar.spasic
 */
#include "processing.h"
#include "utils.h"
#include "peripheral.h"
#include "ADAC2.h"

bool sample_digital[2500];
uint16_t buffer_voltage [2500];
int buffer_adc_cnt = 0;
bool sample_processed[1500];
int sample_processed_cnt=0;
uint8_t response_data[1000];
uint16_t response_data_cnt = 0;
bool RS485_loop = false;
bool ADAC_on = false;
uint8_t buffer_test[data_buffer_lenght];
uint16_t buffer_test_cnt = 0;
int i=0;
int j=0;
bool data_ready = false;
uint16_t data_buffer_cnt = 0;
uint8_t  data_buffer[data_buffer_lenght];
bool timeout_start = false;
int timeout_cnt = 0;
bool proces_timeout = false;
bool data_processing = false;
bool stop = false;
bool start = false;
bool data_check = false;

void processing_timeout_uart0();
void processing_timeout_uart1();

void processing_data(){
	int proc_cnt = 0;
	int r_f_pom_cnt=0;
	int r_f_state_cnt=0;
	sample_digital[0] = 1;
	for(proc_cnt = 1; proc_cnt < buffer_adc_cnt-1; proc_cnt++){
		if(buffer_voltage[proc_cnt]>15241){
			sample_digital[proc_cnt] = 1;
		}
		else{
			sample_digital[proc_cnt] = 0;
		}
	}
	for(int g=0; g<3; g++){
		sample_digital[++proc_cnt] = 1;
	}
	sample_digital[++proc_cnt] = 0;
	sample_processed_cnt=0;

	for(proc_cnt = 0; proc_cnt < buffer_adc_cnt + 4; proc_cnt++){
		if(sample_digital[proc_cnt] == 0 && sample_digital[proc_cnt+1] == 1){
			r_f_pom_cnt = proc_cnt - r_f_state_cnt;
			r_f_pom_cnt = (r_f_pom_cnt/2);
			if(r_f_pom_cnt == 0){
				r_f_pom_cnt = 1;
			}
			while(r_f_pom_cnt > 0){
				sample_processed[sample_processed_cnt++] = 0;
				r_f_pom_cnt--;
			}
			//r_f = true;
			r_f_pom_cnt = 0;
			r_f_state_cnt = proc_cnt;
		}
		else if(sample_digital[proc_cnt] == 1 && sample_digital[proc_cnt+1] == 0){
			r_f_pom_cnt = proc_cnt - r_f_state_cnt;
			r_f_pom_cnt = (r_f_pom_cnt/2) + (r_f_pom_cnt%2);
			while(r_f_pom_cnt > 0){
				sample_processed[sample_processed_cnt++] = 1;
				r_f_pom_cnt--;
			}
			r_f_pom_cnt = 0;
			r_f_state_cnt = proc_cnt;
		}
	}
	for(int g=0; g<9; g++){
		sample_processed[sample_processed_cnt++] = 1;
	}
	sample_processed_cnt -= 9;
}
void data_packing(){
	response_data_cnt = 0;
	response_data[response_data_cnt++] = STX1;
	response_data[response_data_cnt++] = 0x01;//version of protocol

	if(RS485_loop == true){
		adi_gpio_SetLow(LED1.Port, LED1.Pins);
		for(int cnt=0; cnt <= buffer_test_cnt; cnt++){
			response_data[response_data_cnt++] = buffer_test[cnt];
		}
	}
	else{
		adi_gpio_SetHigh(LED1.Port, LED1.Pins);
	}

	response_data[response_data_cnt++] = 0xFF;	//end of string start of sampled datata

	uint8_t mask = 0b10000000;
	uint8_t bit_cnt = 0;
	int cnt = 0;
	if(ADAC_on == true){
		adi_gpio_SetLow(LED2.Port, LED2.Pins);
		for(cnt=0; cnt<sample_processed_cnt; cnt++){
			if(sample_processed[cnt] == true){
				response_data[response_data_cnt] |= mask;
			}
			mask = mask>>1;
			bit_cnt++;
			if(bit_cnt == 8){
				mask = 0b10000000;
				response_data_cnt++;
				bit_cnt=0;
			}
		}
		if(bit_cnt < 8){
			while(bit_cnt != 8){
				cnt++;
				if(sample_processed[cnt] == true){
					response_data[response_data_cnt] |= mask;
				}
				mask = mask>>1;
				bit_cnt++;
			}
			response_data_cnt++;
		}
	}
	else{
		adi_gpio_SetHigh(LED2.Port, LED2.Pins);
	}

	response_data[response_data_cnt] = crc_8(&response_data[2], response_data_cnt - 2);
	response_data_cnt++;
	response_data[response_data_cnt++] = ETX1;
}
void start_sampling(){
	uint16_t adac_check = 0;
	adac2_generic_read(0x23, &adac_check);
	if(adac_check != 0x0201){
		ADAC_on = false;
		ADAC_on = init_ADAC2();
	}
	else {
		ADAC_on = true;
	}
	if(ADAC_on == true){
		adi_gpio_SetGroupInterruptPins(ADAC_RDY.Port, ADI_GPIO_INTA_IRQ, ADAC_RDY.Pins);
	}
}
void stop_sampling(){
	adi_gpio_SetGroupInterruptPins(ADAC_RDY.Port, ADI_GPIO_INTA_IRQ, 0);
	data_ready = false;
}

void processing_start_acquisition(){

	data_buffer_cnt -= 1; // escape version
	if(crc_8(&data_buffer[1], data_buffer_cnt) == 0){
		data_processing = true;

		adi_gpio_SetLow(RS485_RE.Port, RS485_RE.Pins);
		adi_gpio_SetHigh(RS485_DE.Port, RS485_DE.Pins);
		buffer_adc_cnt = 0;
		adi_uart_SubmitRxBuffer(peripherial_get_uart1(), peripherial_get_rxuart1(), 1, 1);
		start_sampling();
		timeout_start = true;
		proces_timeout = true;
		RS485_loop = true;
		adi_uart_SubmitTxBuffer(peripherial_get_uart1(), &data_buffer[1], (data_buffer_cnt-1), 0);
	}
}
void processing_stop_acquisition(){
	timeout_start = false;
	stop_sampling();

	processing_data();

	data_packing();

	adi_uart_SubmitTxBuffer(peripherial_get_uart0(), &response_data[0], response_data_cnt, 0);
	for(i=0;i<1000;i++){
		for(j=0;j<1000;j++){
			__asm__("NOP");
		}
	}
	data_buffer_cnt = 0;
	buffer_test_cnt = 0;
	buffer_adc_cnt = 0;

	memset(response_data, 0 ,1000);
	stop = false;
	data_processing = false;
}
void processing_data_acquisition(){
	adac2_get_conv_results(1, &buffer_voltage[buffer_adc_cnt] );
	buffer_adc_cnt++;
	if(buffer_adc_cnt == (data_buffer_cnt-1)*22){//22
		stop = true;
		response_data[0] = 0;
		RS485_loop = false;
		adi_uart_SubmitRxBuffer(peripherial_get_uart1(), peripherial_get_rxuart1(), 1, 1);
	}
}
void processing_timeout(){
	timeout_cnt++;
	processing_timeout_uart0();
	processing_timeout_uart1();
}

void processing_timeout_uart0(){
	if(start == true && timeout_cnt >205380){
		start = false;
		data_buffer_cnt = 0;
		timeout_start = false;
		timeout_cnt = 0;
	}
}
void processing_timeout_uart1(){
	if(proces_timeout == true && timeout_cnt > 150000){
		proces_timeout = false;
		timeout_start = false;
		timeout_cnt = 0;
		adi_uart_SubmitRxBuffer(peripherial_get_uart1(), peripherial_get_rxuart1(), 1, 1);
		buffer_test_cnt = 0;
		RS485_loop = false;
		ADAC_on = false;
		stop = true;
	}
}

/*set/get*/

inline bool processing_get_start(){
	return  start;
}
inline void processing_set_start(bool x){
	start = x;
}
inline bool processing_get_stop(){
	return  stop;
}
inline void processing_set_stop(bool x){
	stop = x;
}
inline void processing_set_timeout_cnt(int x){
	timeout_cnt = x;
}
inline void processing_set_timeout_start(bool x){
	timeout_start = x;
}
inline bool processing_get_timeout_start(){
	return  timeout_start;
}

inline bool processing_get_data_processing(){
	return  data_processing;
}
inline uint16_t* processing_get_data_buffer_cnt(){
	return &data_buffer_cnt;
}
inline uint8_t*  processing_get_data_buffer(){
	return &data_buffer[0];
}
inline uint8_t* processing_get_buffer_test(){
	return &buffer_test[0];
}
inline uint16_t* processing_get_buffer_test_cnt(){
	return &buffer_test_cnt;
}
inline bool processing_get_data_ready(){
	return  data_ready;
}
inline void processing_set_data_ready(bool x){
	data_ready = x;
}
inline bool processing_get_data_check(){
	return  data_check;
}
inline void processing_set_data_check(bool x){
	data_check = x;
}
