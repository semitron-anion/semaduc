/*
 * utils.h
 *
 *  Created on: 12.12.2019.
 *      Author: aleksandar.spasic
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <stdbool.h>
#include <stdint.h>

void delay_ms(uint16_t time);
uint8_t crc_8(uint8_t *data, uint8_t data_num);

#endif /* UTILS_H_ */
