/*
 * callback.c
 *
 *  Created on: 12.12.2019.
 *      Author: aleksandar.spasic
 */
#include "callback.h"
#include <stdint.h>
#include "peripheral.h"
#include "processing.h"

static void UARTCallback0(
    void        *pAppHandle,
    uint32_t     nEvent,
    void        *pArg
){
	uint8_t recive=0;
	switch(nEvent){
	case ADI_UART_EVENT_RX_BUFFER_PROCESSED:
		recive = *peripherial_get_rxuart0();
		adi_uart_SubmitRxBuffer(peripherial_get_uart0(), peripherial_get_rxuart0(), 1, 1);
		if(recive == STX1 && processing_get_start() == false && processing_get_data_processing() == false){
			processing_set_start(true);
			processing_set_timeout_cnt(0);
			processing_set_timeout_start(true);
			*processing_get_data_buffer_cnt() = 0;
		}
		else if(recive == ETX1){
			processing_set_start(false);
			processing_set_data_check(true);
			processing_set_timeout_start(false);
			processing_set_timeout_cnt(0);
		}
		else if(processing_get_start() == true){
			if(*processing_get_data_buffer_cnt() > data_buffer_lenght - 1){
				processing_set_start(false);
				*processing_get_data_buffer_cnt() = 0;
			}
			else{
				*(processing_get_data_buffer()+(*processing_get_data_buffer_cnt())) = recive;
				*processing_get_data_buffer_cnt() = *processing_get_data_buffer_cnt() +1;
			}
		}
		break;
	}
}
static void UARTCallback1(
    void        *pAppHandle,
    uint32_t     nEvent,
    void        *pArg
){
	uint8_t recive=0;
	switch(nEvent){
	case ADI_UART_EVENT_RX_BUFFER_PROCESSED:
		recive = *peripherial_get_rxuart1();
		adi_uart_SubmitRxBuffer(peripherial_get_uart1(), peripherial_get_rxuart1(), 1, 1);
		*(processing_get_buffer_test()+(*processing_get_buffer_test_cnt())) = recive;
		*processing_get_buffer_test_cnt() = *processing_get_buffer_test_cnt() + 1;

		if((*processing_get_buffer_test_cnt() > data_buffer_lenght) || *processing_get_buffer_test_cnt() >= (*processing_get_data_buffer_cnt() - 1)){
			*processing_get_buffer_test_cnt() = *processing_get_buffer_test_cnt() - 1;
			processing_set_stop(true);
		}
		break;
	}
}
static void GPIOCallback0(
    void        *pAppHandle,
    uint32_t     nEvent,
    void        *pArg
){
	processing_set_data_ready(true);
}

/*set/get*/

inline void* callback_get_uart0(){
	return &UARTCallback0;
}
inline void* callback_get_uart1(){
	return &UARTCallback1;
}
inline void* callback_get_gpio(){
	return &GPIOCallback0;
}

