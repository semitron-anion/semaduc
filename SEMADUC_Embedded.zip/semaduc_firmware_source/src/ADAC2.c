/*
 * ADAC2.c
 *
 *  Created on: 12.12.2019.
 *      Author: aleksandar.spasic
 */
#include "ADAC2.h"
#include "peripheral.h"

bool init_ADAC2(){
	bool on_off = false;
	delay_ms(50);
	adac2_reset();
	delay_ms(30);
	uint16_t id = 0;
	id = 0;
	adac2_generic_read( 0x46, &id);
	if(id == 0x08){
		on_off = true;
	}
	adac2_default_cfg();
	return on_off;
}
void adac2_default_cfg()
{
    adac2_generic_write( 0x05, 0x08 );
    adac2_enable_ch( 1 );
    adac2_set_ch_func( 1, 0x03 );
    adac2_generic_write( 0x23, 0x0201 );
}
void adac2_reset(){
	adi_gpio_SetLow(ADAC_RST.Port, ADAC_RST.Pins);
	delay_ms(2);
	adi_gpio_SetHigh(ADAC_RST.Port, ADAC_RST.Pins);
	delay_ms(30);
}
void adac2_generic_write(uint8_t reg_addr, uint16_t data_in )
{
    uint8_t tx_data[ 4 ] = { 0 };
    uint8_t rx_data[ 4 ] = { 0 };

    tx_data[ 0 ] = reg_addr;
    tx_data[ 1 ] = data_in >> 8;
    tx_data[ 2 ] = data_in;
    tx_data[ 3 ] = crc_8( tx_data, 3 );

    spi_send(tx_data, 4, rx_data, 4);
}
adac2_err_t adac2_generic_read(uint8_t reg_addr, uint16_t *data_out)
{
    uint8_t tx_data[ 4 ] = { 0 };
    uint8_t rx_data[ 4 ] = { 0 };
    uint16_t ret_val = 0;
    uint8_t crc8 = 0;

    tx_data[ 0 ] = 0x41;
    tx_data[ 1 ] = ADAC2_RD_RET_INFO | ADAC2_RD_AUTO_EN;
    tx_data[ 2 ] = reg_addr;
    tx_data[ 3 ] = crc_8( tx_data, 3 );

    spi_send(tx_data, 4, rx_data, 4);

    tx_data[ 0 ] = 0x44;
    tx_data[ 1 ] = 0;
    tx_data[ 2 ] = 0;
    tx_data[ 3 ] = crc_8( tx_data, 3 );

    spi_send(tx_data, 4, rx_data, 4);

    if ( ( rx_data[ 0 ] & ADAC2_FRAME_RD_MASK_RESERVED_BIT ) == 0 )
     {
         return ADAC2_ERR_RD_STATUS;
     }

     crc8 = crc_8( rx_data, 3 );

     if ( crc8 != rx_data[ 3 ] )
     {
         return ADAC2_ERR_CRC;
     }

     if ( data_out != NULL )
     {
         ret_val = rx_data[ 1 ];
         ret_val <<= 8;
         ret_val |= rx_data[ 2 ];
         *data_out = ret_val;
     }

     return ADAC2_ERR_STATUS_OK;
}
void adac2_enable_ch(uint8_t channel )
{
    uint16_t read_data = 0;

    adac2_generic_read( 0x23, &read_data);

    read_data &= ~( (uint16_t)ADAC2_EN_CONV_MASK << ADAC2_EN_CONV_OFFSET_CH );
    read_data |= channel << ADAC2_EN_CONV_OFFSET_CH;

    adac2_generic_write( 0x23, read_data );
}
void adac2_set_ch_func(uint8_t channel, uint8_t ch_func )
{
    uint8_t ch_addr;

    ch_addr = channel - ( ( channel >> 2 ) * ( channel >> 2 ) );

    adac2_generic_write( ch_addr, ch_func );
}
adac2_err_t adac2_get_conv_results(uint8_t channel, uint16_t *data_out )
{
    uint16_t read_data = 0;
    adac2_err_t error;
    uint8_t ch_addr;

    ch_addr = channel - ( ( channel >> 2 ) * ( channel >> 2 ) );
    ch_addr += ADAC2_REG_OFFSET_CONV_RES;

    if ( (error = adac2_generic_read( ch_addr, &read_data)) )
    {
        return error;
    }

    if ( data_out != NULL )
    {
        *data_out = read_data;
    }

    return ADAC2_ERR_STATUS_OK;
}
