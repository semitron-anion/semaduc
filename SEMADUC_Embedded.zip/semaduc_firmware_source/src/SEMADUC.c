/*****************************************************************************
 * SEMADUC.c
 *****************************************************************************/

#include <sys/platform.h>
#include "adi_initialize.h"
#include "SEMADUC.h"


int main(int argc, char *argv[])
{
	adi_initComponents();
	peripheral_init();
	init_ADAC2();
	while(1){
		if(processing_get_data_check()){
			processing_start_acquisition();
			processing_set_data_check(false);
		}
		if(processing_get_stop()){
			processing_stop_acquisition();
		}
		if(processing_get_data_ready()){
			if(!processing_get_stop()){
				processing_data_acquisition();
			}
			processing_set_data_ready(false);
		}
		if(processing_get_timeout_start()){
			processing_timeout();
		}
	}
	return 0;
}

