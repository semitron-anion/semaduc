/*
 * ADAC2.h
 *
 *  Created on: 12.12.2019.
 *      Author: aleksandar.spasic
 */

#ifndef ADAC2_H_
#define ADAC2_H_

#include <stdbool.h>
#include <stdint.h>
#include "utils.h"


#define ADAC2_RD_RET_INFO  0x01
#define ADAC2_RD_AUTO_EN  0x02
#define ADAC2_FRAME_RD_MASK_RESERVED_BIT  0x80
#define ADAC2_EN_CONV_MASK         0x0F
#define ADAC2_EN_CONV_OFFSET_CH    0
#define ADAC2_EN_CONV_OFFSET_DIAG  4
#define ADAC2_REG_OFFSET_CONV_RES  0x25
typedef enum
{
    ADAC2_ERR_STATUS_OK,
    ADAC2_ERR_INIT_DRV,
    ADAC2_ERR_RD_STATUS,
    ADAC2_ERR_RD_NWORDS,
    ADAC2_ERR_CRC

} adac2_err_t;

bool init_ADAC2();
void adac2_default_cfg();
void adac2_reset();
void adac2_generic_write(uint8_t reg_addr, uint16_t data_in );
adac2_err_t adac2_generic_read(uint8_t reg_addr, uint16_t *data_out);
void adac2_enable_ch(uint8_t channel );
void adac2_set_ch_func(uint8_t channel, uint8_t ch_func );
adac2_err_t adac2_get_conv_results(uint8_t channel, uint16_t *data_out );

#endif /* ADAC2_H_ */
