/*
 * peripheral.h
 *
 *  Created on: 12.12.2019.
 *      Author: aleksandar.spasic
 */

#ifndef PERIPHERAL_H_
#define PERIPHERAL_H_

#include <drivers/gpio/adi_gpio.h>
#include <drivers/uart/adi_uart.h>
#include <drivers/pwr/adi_pwr.h>
#include <drivers/spi/adi_spi.h>
#include <drivers/gpio/adi_gpio.h>

typedef struct {
    ADI_GPIO_PORT Port;
    ADI_GPIO_DATA Pins;
} PinMap;
extern PinMap LED1;
extern PinMap LED2;
extern PinMap BTN1;
extern PinMap BTN2;

extern PinMap ADAC_CS;
extern PinMap ADAC_RST;
extern PinMap ADAC_ALT;
extern PinMap ADAC_RDY;

extern PinMap RS485_RE;
extern PinMap RS485_DE;

void peripheral_init();
void spi_send(uint8_t *transmit, uint16_t transmit_lenght, uint8_t *recive, uint16_t recive_lenght);
ADI_UART_HANDLE peripherial_get_uart0();
ADI_UART_HANDLE peripherial_get_uart1();
char* peripherial_get_rxuart0();
char* peripherial_get_rxuart1();

#endif /* PERIPHERAL_H_ */
