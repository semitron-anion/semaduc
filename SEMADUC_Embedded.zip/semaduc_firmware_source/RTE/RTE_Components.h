/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: SEMADUC
 * RTE configuration: system.rteconfig
*/
#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

/*
 * Define the Device Header File:
*/
#define CMSIS_device_header "ADuCM4050.h"

#define ADUCM4050_SI_REV  1             /* ADuCM4050 Si. Rev. 0.1 */

#endif /* RTE_COMPONENTS_H */
