/*
 **
 ** Source file generated on December 13, 2019 at 14:36:53.	
 **
 ** Copyright (C) 2011-2019 Analog Devices Inc., All Rights Reserved.
 **
 ** This file is generated automatically based upon the options selected in 
 ** the Pin Multiplexing configuration editor. Changes to the Pin Multiplexing
 ** configuration should be made by changing the appropriate options rather
 ** than editing this file.
 **
 ** Selected Peripherals
 ** --------------------
 ** SPI0 (CLK, MOSI, MISO)
 ** UART0 (Tx, Rx)
 ** UART1 (Tx, Rx)
 **
 ** GPIO (unavailable)
 ** ------------------
 ** P0_00, P0_01, P0_02, P0_10, P0_11, P1_15, P2_00
 */

#include <sys/platform.h>
#include <stdint.h>

#define SPI0_CLK_PORTP0_MUX  ((uint16_t) ((uint16_t) 1<<0))
#define SPI0_MOSI_PORTP0_MUX  ((uint16_t) ((uint16_t) 1<<2))
#define SPI0_MISO_PORTP0_MUX  ((uint16_t) ((uint16_t) 1<<4))
#define UART0_TX_PORTP0_MUX  ((uint32_t) ((uint32_t) 1<<20))
#define UART0_RX_PORTP0_MUX  ((uint32_t) ((uint32_t) 1<<22))
#define UART1_TX_PORTP1_MUX  ((uint32_t) ((uint32_t) 2<<30))
#define UART1_RX_PORTP2_PIN0_MUX  ((uint16_t) ((uint16_t) 2<<0))

int32_t adi_initpinmux(void);

/*
 * Initialize the Port Control MUX Registers
 */
int32_t adi_initpinmux(void) {
    /* PORTx_MUX registers */
    *pREG_GPIO0_CFG = SPI0_CLK_PORTP0_MUX | SPI0_MOSI_PORTP0_MUX
     | SPI0_MISO_PORTP0_MUX | UART0_TX_PORTP0_MUX | UART0_RX_PORTP0_MUX;
    *pREG_GPIO1_CFG = UART1_TX_PORTP1_MUX;
    *pREG_GPIO2_CFG = UART1_RX_PORTP2_PIN0_MUX;

    return 0;
}

